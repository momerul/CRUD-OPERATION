﻿using System; 
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FinalTask.Models;
using System.Data.Entity;
using FinalTask.DataAccessLayer;

namespace FinalTask.Controllers
{
    public class EmployeeController : Controller
    {
        DAL da = new DAL();
        BusinessEntity entity = new BusinessEntity();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ViewAll()
        {
            return View(da.GetAllEmployee());
        }

        public ActionResult AddOrEdit(int id = 0)
        {
            return View(da.AddOrEditDetails());
        }

        [HttpPost]
        public ActionResult AddOrEdit()
        {
            return View(da.AddOrEditDetailsAll(entity));
        }

        public ActionResult Delete(int id)
        {
            return (da.Delete(id));
        }
    }
}