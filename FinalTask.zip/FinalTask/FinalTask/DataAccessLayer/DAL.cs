﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FinalTask.Models;
using FinalTask.Controllers;
using FinalTask;
using System.Data.Entity;
using System.Web.Mvc;

namespace FinalTask.DataAccessLayer
{
    public class DAL
    {
        public IEnumerable<BusinessEntity> GetAllEmployee()
        {
            using (DBConnect db = new DBConnect())
            {
                return db.BusinessEntities.ToList<BusinessEntity>();
            }
        }

        public BusinessEntity AddOrEditDetails(int id=0)
        {
            BusinessEntity business = new BusinessEntity();

            if (id != 0)
            {
                using (DBConnect db = new DBConnect())
                {
                    business = db.BusinessEntities.Where(x => x.BusinessId == id).FirstOrDefault<BusinessEntity>();
                }
            }

            return business;
        }

        public JsonResult AddOrEditDetailsAll(BusinessEntity entity)
        {
            try
            {
                using (DBConnect db = new DBConnect())
                {
                    if (entity.BusinessId == 0)
                    {
                        db.BusinessEntities.Add(entity);
                        db.SaveChanges();
                    }
                    else
                    {
                        db.Entry(entity).State = EntityState.Modified;
                        db.SaveChanges();
                    }
                }
                return Json(new {message = "Submitted Successfully" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult Delete(int id)
        {
            try
            {
                using (DBConnect db = new DBConnect())
                {
                    BusinessEntity business = db.BusinessEntities.Where(x => x.BusinessId == id).FirstOrDefault<BusinessEntity>();
                    db.BusinessEntities.Remove(business);
                    db.SaveChanges();
                }
                return Json(new {message = "Deleted Successfully" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        private JsonResult Json(object p, JsonRequestBehavior allowGet)
        {
            throw new NotImplementedException();
        }
    }
}