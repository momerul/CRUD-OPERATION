﻿using System;

namespace DataAccess
{
    public class DAL
    {
        
    }
}
